<?php

session_start();

require_once __DIR__ . '/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 3) {
    header('Location: login.php');
    exit;
}

$sql = "SELECT * FROM polls
        WHERE POLL_STATUS = 'Активен'
        ORDER BY POLL_ID DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute();

$polls = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="ru">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Опросы</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap"
        rel="stylesheet"
    >

    <link rel="stylesheet" href="css/style.css">

</head>

<body>

<header>

    <div class="container">

        <div class="logo">

            <a href="index.php">

                <span>МУИВ</span>

                <small>Web-портал опросов</small>

            </a>

        </div>

        <nav>

            <ul class="menu">

                <li>
                    <a href="index.php">
                        Главная
                    </a>
                </li>

                <li>
                    <a href="polls.php">
                        Опросы
                    </a>
                </li>

                <li>
                    <a href="about.php">
                        О нас
                    </a>
                </li>

            </ul>

        </nav>

    </div>

</header>

<main>

<section class="polls-page">

    <div class="container">

        <div class="breadcrumbs">

            <a href="index.php">
                Главная
            </a>

            <span>→</span>

            <a href="profile.php">
                Личный кабинет
            </a>

            <span>→</span>

            <span>
                Опросы
            </span>

        </div>

        <h1>
            Доступные опросы
        </h1>

        <div class="polls">

            <?php if (count($polls) > 0): ?>

                <?php foreach ($polls as $poll): ?>

                    <div class="poll-card">

                        <h2>
                            <?= htmlspecialchars($poll['POLL_TITLE']) ?>
                        </h2>

                        <p>

                            <strong>
                                Описание:
                            </strong>

                            <?= htmlspecialchars($poll['POLL_DESCRIPTION']) ?>

                        </p>

                        <p>

                            <strong>
                                Статус:
                            </strong>

                            <?= htmlspecialchars($poll['POLL_STATUS']) ?>

                        </p>

                        <p>

                            <strong>
                                Дата окончания:
                            </strong>

                            <?= htmlspecialchars($poll['POLL_END_DATE']) ?>

                        </p>

                        <a
                            href="poll.php?id=<?= $poll['POLL_ID'] ?>"
                            class="btn"
                        >
                            Пройти опрос
                        </a>

                    </div>

                <?php endforeach; ?>

            <?php else: ?>

                <p style="text-align:center;">
                    Доступных опросов пока нет.
                </p>

            <?php endif; ?>

        </div>

    </div>

</section>

</main>

<footer>

    © 2026 Московский университет им. С.Ю. Витте

</footer>

</body>

</html>